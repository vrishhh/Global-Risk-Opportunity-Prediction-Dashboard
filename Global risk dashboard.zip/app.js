// Risk Data
const risksData = {
  macroeconomic: [
    { name: "Global Growth Slowdown", likelihood: 0.7, impact: 4, sector: ["Manufacturing", "Export"], status: "high", trend: "increasing" },
    { name: "Currency Volatility", likelihood: 0.8, impact: 3, sector: ["Finance", "Import-Export"], status: "high", trend: "increasing" },
    { name: "Inflation Pressures", likelihood: 0.4, impact: 2, sector: ["Consumer", "Banking"], status: "low", trend: "decreasing" },
    { name: "Debt Concerns", likelihood: 0.5, impact: 3, sector: ["Finance", "Government"], status: "medium", trend: "stable" },
    { name: "Trade Disruptions", likelihood: 0.6, impact: 4, sector: ["Import-Export", "Manufacturing"], status: "high", trend: "increasing" }
  ],
  geopolitical: [
    { name: "US-China Tensions", likelihood: "Likely", impact: "High", score: 8, regions: ["Asia-Pacific", "Global"], status: "critical" },
    { name: "India-Pakistan Tensions", likelihood: "Unlikely", impact: "High", score: 4, regions: ["South Asia"], status: "medium" },
    { name: "Middle East Conflicts", likelihood: "Likely", impact: "High", score: 7, regions: ["Middle East", "Global"], status: "high" },
    { name: "South China Sea Disputes", likelihood: "Likely", impact: "Medium", score: 6, regions: ["Southeast Asia"], status: "high" },
    { name: "Technology Decoupling", likelihood: "Likely", impact: "High", score: 7, regions: ["Global"], status: "high" }
  ],
  environmental: [
    { name: "Monsoon Variability", likelihood: 0.75, impact: 4, sector: ["Agriculture", "Hydropower"], status: "high", trend: "increasing" },
    { name: "Extreme Weather Events", likelihood: 0.65, impact: 4, sector: ["Agriculture", "Infrastructure", "Insurance"], status: "high", trend: "increasing" },
    { name: "Drought/Flood Cycles", likelihood: 0.7, impact: 3, sector: ["Agriculture", "Water", "Energy"], status: "high", trend: "increasing" },
    { name: "Renewable Grid Strain", likelihood: 0.6, impact: 3, sector: ["Energy", "Utilities"], status: "medium", trend: "increasing" }
  ],
  operational: [
    { name: "Port Congestion", likelihood: 0.5, impact: 3, sector: ["Logistics", "Trade"], status: "medium", trend: "stable" },
    { name: "Supplier Delays", likelihood: 0.6, impact: 3, sector: ["Manufacturing", "Retail"], status: "high", trend: "increasing" },
    { name: "Labor Strikes", likelihood: 0.4, impact: 2, sector: ["Manufacturing", "Services"], status: "low", trend: "stable" },
    { name: "Cybersecurity Breaches", likelihood: 0.5, impact: 4, sector: ["Finance", "Tech", "Telecom"], status: "medium", trend: "increasing" },
    { name: "Regulatory Changes", likelihood: 0.7, impact: 2, sector: ["Finance", "Energy", "Tech"], status: "medium", trend: "stable" }
  ]
};

const sectoralData = [
  { name: "Agriculture", risk_score: 63, status: "acceptable", opportunities: ["Sustainable practices", "Tech adoption"], growth_potential: 8 },
  { name: "Manufacturing", risk_score: 68, status: "moderate", opportunities: ["Automation", "Export expansion"], growth_potential: 12 },
  { name: "Banking & Finance", risk_score: 45, status: "low", opportunities: ["Digital payments", "FinTech"], growth_potential: 15 },
  { name: "Energy & Utilities", risk_score: 72, status: "high", opportunities: ["Renewable expansion", "Storage solutions"], growth_potential: 18 },
  { name: "Tech & IT", risk_score: 55, status: "moderate", opportunities: ["AI/ML adoption", "Cloud services"], growth_potential: 20 },
  { name: "Supply Chain & Logistics", risk_score: 78, status: "high", opportunities: ["Digitalization", "Alternative routes"], growth_potential: 14 }
];

const opportunitiesData = [
  { name: "Renewable Energy Investments", growth_potential: 15, timeframe: "3-5 years", capital_required: "High" },
  { name: "Export Sector Resilience", growth_potential: 12, timeframe: "1-2 years", capital_required: "Medium" },
  { name: "Digital Transformation", growth_potential: 18, timeframe: "2-3 years", capital_required: "High" },
  { name: "Infrastructure Development", growth_potential: 14, timeframe: "3-5 years", capital_required: "Very High" }
];

let kpisData = {
  gdp_growth: { value: 7.81, unit: "%", trend: "up", status: "good", source: "RBI", label: "India GDP Growth Rate" },
  inflation: { value: 0.25, unit: "%", trend: "down", status: "excellent", source: "MOSPI", label: "CPI Inflation" },
  repo_rate: { value: 5.50, unit: "%", trend: "stable", status: "neutral", source: "RBI", label: "Repo Rate" },
  forex_reserves: { value: 689.73, unit: "Bn USD", trend: "up", status: "good", source: "RBI", label: "Foreign Exchange Reserves" },
  debt_to_gdp: { value: 55.13, unit: "%", trend: "down", status: "acceptable", source: "Ministry of Finance", label: "Debt to GDP Ratio" },
  renewable_capacity: { value: 247, unit: "GW", trend: "up", status: "good", source: "Ministry of Power", label: "Renewable Capacity" },
  port_activity: { value: 72, unit: "Index", trend: "down", status: "warning", source: "Port Authorities", label: "Port Activity Index" },
  supply_chain_health: { value: 65, unit: "Score", trend: "down", status: "warning", source: "Supply Chain Analytics", label: "Supply Chain Health" }
};

let alertsData = [
  { title: "Port Congestion at Mundra", category: "Operational", severity: "critical", description: "7-day cargo backlog detected due to flooding", action: "Divert shipments to alternative ports", time: "2 hours ago" },
  { title: "Monsoon Risk Peak Period", category: "Environmental", severity: "high", description: "High probability of disruptions in next 2 weeks", action: "Secure inventory and alternative supply routes", time: "4 hours ago" },
  { title: "Banking Sector Credit Risk Rising", category: "Macroeconomic", severity: "high", description: "Credit risk indicators show upward trend", action: "Review lending portfolios and provisions", time: "6 hours ago" },
  { title: "Energy Grid Renewable Curtailment", category: "Environmental", severity: "medium", description: "Grid curtailments observed in Rajasthan", action: "Plan for battery storage investments", time: "12 hours ago" },
  { title: "Labor Union Activity Escalating", category: "Operational", severity: "medium", description: "Multiple strike announcements in manufacturing sector", action: "Engage with union representatives", time: "1 day ago" }
];

// State
let currentRole = 'executive';
let selectedRisk = null;

// Initialize
function init() {
  updateLastUpdateTime();
  setupEventListeners();
  renderHeatMap();
  renderKPIs();
  renderGeopoliticalRisks();
  renderSectoralAssessment();
  renderAlerts();
  renderOpportunities();
  
  // Start real-time updates
  setInterval(() => {
    updateRealTimeData();
    updateLastUpdateTime();
  }, 5000);
}

function updateLastUpdateTime() {
  const now = new Date();
  const timeString = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  document.getElementById('lastUpdateTime').textContent = timeString;
}

function setupEventListeners() {
  // Tab navigation
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tabId = btn.dataset.tab;
      switchTab(tabId);
    });
  });
  
  // Role selector
  document.getElementById('roleSelector').addEventListener('change', (e) => {
    currentRole = e.target.value;
    updateDashboardForRole();
  });
  
  // Refresh button
  document.getElementById('refreshBtn').addEventListener('click', () => {
    updateRealTimeData();
    updateLastUpdateTime();
  });
  
  // Category filter
  document.querySelectorAll('.category-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.category-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      const category = item.dataset.category;
      filterByCategory(category);
    });
  });
  
  // Close sidebar
  document.getElementById('closeSidebar').addEventListener('click', () => {
    document.getElementById('rightSidebar').classList.remove('open');
    selectedRisk = null;
  });
}

function switchTab(tabId) {
  // Update tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.tab === tabId) {
      btn.classList.add('active');
    }
  });
  
  // Update tab panes
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.remove('active');
  });
  document.getElementById(tabId).classList.add('active');
}

function renderHeatMap() {
  const grid = document.getElementById('heatmapGrid');
  grid.innerHTML = '';
  
  // Create 5x5 grid cells
  for (let i = 0; i < 25; i++) {
    const cell = document.createElement('div');
    cell.className = 'heatmap-cell';
    grid.appendChild(cell);
  }
  
  // Add risk dots
  const allRisks = [
    ...risksData.macroeconomic,
    ...risksData.environmental,
    ...risksData.operational
  ];
  
  allRisks.forEach((risk, index) => {
    const dot = document.createElement('div');
    dot.className = `risk-dot ${risk.status}`;
    
    // Position based on likelihood and impact
    const x = risk.likelihood * 100;
    const y = 100 - (risk.impact / 5 * 100);
    
    // Add some random offset to prevent overlap
    const offsetX = (Math.random() - 0.5) * 10;
    const offsetY = (Math.random() - 0.5) * 10;
    
    dot.style.left = `${x + offsetX}%`;
    dot.style.top = `${y + offsetY}%`;
    dot.style.transform = 'translate(-50%, -50%)';
    
    dot.addEventListener('click', () => showRiskDetails(risk));
    dot.addEventListener('mouseenter', (e) => showTooltip(e, risk.name));
    dot.addEventListener('mouseleave', hideTooltip);
    
    grid.appendChild(dot);
  });
}

function renderKPIs() {
  const grid = document.getElementById('kpiGrid');
  grid.innerHTML = '';
  
  Object.entries(kpisData).forEach(([key, kpi]) => {
    const card = document.createElement('div');
    card.className = 'kpi-card';
    
    const trendIcon = kpi.trend === 'up' ? '↑' : kpi.trend === 'down' ? '↓' : '→';
    const trendColor = kpi.trend === 'up' ? 'var(--color-success)' : kpi.trend === 'down' ? 'var(--color-error)' : 'var(--color-text-secondary)';
    
    card.innerHTML = `
      <div class="kpi-header">
        <div class="kpi-label">${kpi.label}</div>
        <div class="kpi-trend" style="color: ${trendColor}">${trendIcon}</div>
      </div>
      <div class="kpi-value">${kpi.value}${kpi.unit}</div>
      <div class="kpi-footer">
        <span class="kpi-status ${kpi.status}">${kpi.status.toUpperCase()}</span>
        <span class="kpi-source">${kpi.source}</span>
      </div>
    `;
    
    grid.appendChild(card);
  });
}

function renderGeopoliticalRisks() {
  const list = document.getElementById('geoRisksList');
  list.innerHTML = '';
  
  risksData.geopolitical.forEach(risk => {
    const item = document.createElement('div');
    item.className = `geo-risk-item ${risk.status}`;
    item.innerHTML = `
      <div class="geo-risk-name">${risk.name}</div>
      <div class="geo-risk-meta">
        <span>${risk.likelihood}</span>
        <span>Score: ${risk.score}/10</span>
      </div>
    `;
    item.addEventListener('click', () => showRiskDetails(risk));
    list.appendChild(item);
  });
}

function renderSectoralAssessment() {
  const grid = document.getElementById('sectoralGrid');
  grid.innerHTML = '';
  
  sectoralData.forEach(sector => {
    const card = document.createElement('div');
    card.className = 'sector-card';
    
    const scoreClass = sector.risk_score >= 70 ? 'high' : sector.risk_score >= 60 ? 'moderate' : sector.risk_score >= 50 ? 'acceptable' : 'low';
    
    card.innerHTML = `
      <div class="sector-header">
        <div class="sector-name">${sector.name}</div>
        <div class="sector-score ${scoreClass}">${sector.risk_score}</div>
      </div>
      <div class="sector-status ${sector.status}">${sector.status}</div>
      <div class="sector-opportunities">
        <strong>Opportunities:</strong> ${sector.opportunities.join(', ')}
      </div>
      <div class="sector-growth">
        <span>↗</span>
        <span>Growth Potential: ${sector.growth_potential}%</span>
      </div>
    `;
    
    grid.appendChild(card);
  });
}

function renderAlerts() {
  const list = document.getElementById('alertsList');
  list.innerHTML = '';
  
  // Count alerts by severity
  const criticalCount = alertsData.filter(a => a.severity === 'critical').length;
  const highCount = alertsData.filter(a => a.severity === 'high').length;
  const mediumCount = alertsData.filter(a => a.severity === 'medium').length;
  
  document.getElementById('criticalCount').textContent = criticalCount;
  document.getElementById('highCount').textContent = highCount;
  document.getElementById('mediumCount').textContent = mediumCount;
  
  // Render alerts
  alertsData.forEach(alert => {
    const item = document.createElement('div');
    item.className = `alert-item ${alert.severity}`;
    item.innerHTML = `
      <div class="alert-header">
        <div class="alert-title">${alert.title}</div>
        <div class="alert-severity ${alert.severity}">${alert.severity}</div>
      </div>
      <div class="alert-description">${alert.description}</div>
      <div class="alert-action">→ ${alert.action}</div>
      <div class="alert-footer">
        <span>${alert.category}</span>
        <span>${alert.time}</span>
      </div>
    `;
    list.appendChild(item);
  });
}

function renderOpportunities() {
  const grid = document.getElementById('opportunitiesGrid');
  grid.innerHTML = '';
  
  opportunitiesData.forEach(opp => {
    const card = document.createElement('div');
    card.className = 'opportunity-card';
    card.innerHTML = `
      <div class="opportunity-header">
        <div class="opportunity-name">${opp.name}</div>
        <div class="opportunity-growth">+${opp.growth_potential}%</div>
      </div>
      <div class="opportunity-meta">
        <div class="opportunity-meta-item">
          <span>Timeframe:</span>
          <span>${opp.timeframe}</span>
        </div>
        <div class="opportunity-meta-item">
          <span>Capital Required:</span>
          <span>${opp.capital_required}</span>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });
}

function showRiskDetails(risk) {
  selectedRisk = risk;
  const sidebar = document.getElementById('rightSidebar');
  const details = document.getElementById('riskDetails');
  
  let detailsHTML = `
    <div class="detail-section">
      <div class="detail-label">Risk Name</div>
      <div class="detail-value">${risk.name}</div>
    </div>
  `;
  
  if (risk.likelihood !== undefined) {
    const likelihoodPercent = typeof risk.likelihood === 'number' ? (risk.likelihood * 100).toFixed(0) : risk.likelihood;
    detailsHTML += `
      <div class="detail-section">
        <div class="detail-label">Probability</div>
        <div class="detail-value">${likelihoodPercent}${typeof risk.likelihood === 'number' ? '%' : ''}</div>
      </div>
    `;
  }
  
  if (risk.impact !== undefined) {
    detailsHTML += `
      <div class="detail-section">
        <div class="detail-label">Impact Level</div>
        <div class="detail-value">${risk.impact}/5</div>
      </div>
    `;
  }
  
  if (risk.sector) {
    detailsHTML += `
      <div class="detail-section">
        <div class="detail-label">Affected Sectors</div>
        <div class="affected-sectors">
          ${risk.sector.map(s => `<span class="sector-tag">${s}</span>`).join('')}
        </div>
      </div>
    `;
  }
  
  if (risk.trend) {
    detailsHTML += `
      <div class="detail-section">
        <div class="detail-label">Trend</div>
        <div class="detail-value" style="text-transform: capitalize;">${risk.trend}</div>
      </div>
    `;
  }
  
  if (risk.regions) {
    detailsHTML += `
      <div class="detail-section">
        <div class="detail-label">Affected Regions</div>
        <div class="affected-sectors">
          ${risk.regions.map(r => `<span class="sector-tag">${r}</span>`).join('')}
        </div>
      </div>
    `;
  }
  
  detailsHTML += `
    <div class="detail-section">
      <div class="detail-label">Mitigation Strategies</div>
      <ul class="mitigation-list">
        <li>Regular monitoring and assessment</li>
        <li>Diversification of exposure</li>
        <li>Contingency planning and risk hedging</li>
        <li>Stakeholder communication protocols</li>
      </ul>
    </div>
  `;
  
  details.innerHTML = detailsHTML;
  sidebar.classList.add('open');
}

function showTooltip(e, text) {
  let tooltip = document.querySelector('.tooltip');
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    document.body.appendChild(tooltip);
  }
  
  tooltip.textContent = text;
  tooltip.style.left = e.pageX + 10 + 'px';
  tooltip.style.top = e.pageY + 10 + 'px';
  tooltip.classList.add('show');
}

function hideTooltip() {
  const tooltip = document.querySelector('.tooltip');
  if (tooltip) {
    tooltip.classList.remove('show');
  }
}

function updateRealTimeData() {
  // Simulate real-time updates with small random changes
  Object.keys(kpisData).forEach(key => {
    const kpi = kpisData[key];
    const change = (Math.random() - 0.5) * 0.5;
    kpi.value = parseFloat((kpi.value + change).toFixed(2));
  });
  
  renderKPIs();
}

function updateDashboardForRole() {
  // Different roles see different levels of detail
  // This is a simplified implementation
  console.log(`Dashboard updated for role: ${currentRole}`);
}

function filterByCategory(category) {
  if (category === 'all') {
    renderHeatMap();
  } else {
    // Filter heat map by category
    const grid = document.getElementById('heatmapGrid');
    grid.innerHTML = '';
    
    // Create 5x5 grid cells
    for (let i = 0; i < 25; i++) {
      const cell = document.createElement('div');
      cell.className = 'heatmap-cell';
      grid.appendChild(cell);
    }
    
    // Add filtered risk dots
    const filteredRisks = risksData[category] || [];
    
    filteredRisks.forEach((risk, index) => {
      if (risk.likelihood !== undefined && typeof risk.likelihood === 'number') {
        const dot = document.createElement('div');
        dot.className = `risk-dot ${risk.status}`;
        
        const x = risk.likelihood * 100;
        const y = 100 - (risk.impact / 5 * 100);
        
        const offsetX = (Math.random() - 0.5) * 10;
        const offsetY = (Math.random() - 0.5) * 10;
        
        dot.style.left = `${x + offsetX}%`;
        dot.style.top = `${y + offsetY}%`;
        dot.style.transform = 'translate(-50%, -50%)';
        
        dot.addEventListener('click', () => showRiskDetails(risk));
        dot.addEventListener('mouseenter', (e) => showTooltip(e, risk.name));
        dot.addEventListener('mouseleave', hideTooltip);
        
        grid.appendChild(dot);
      }
    });
  }
}

// Initialize app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}